# Lumen — Creator Platform Landing Page

An original, redesigned landing page for a creator-monetization platform,
built with React + Vite, Tailwind CSS, and Framer Motion. Inspired by the
general concept of the page you shared (a creator-economy signup site), but
with fresh copy, a distinct "backstage / spotlight" visual identity, and
3D motion throughout — not a copy of the original's design or text.

## Design concept

- **Palette:** deep plum-black stage background, warm gold spotlight accent,
  coral secondary, cream text.
- **Type:** Fraunces (display serif) + Manrope (body) + Space Mono (data/labels).
- **Signature element:** a 3D flipping "Creator Pass" membership card in the
  final section — click it to see what it unlocks.
- **Motion:** a rotating spotlight cone in the hero, mouse-tilted 3D cards
  throughout, a scroll-drawn timeline in "How it works", and count-up stats.
- Respects `prefers-reduced-motion`.

## Getting started

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually `http://localhost:5173`).

To build for production:

```bash
npm run build
npm run preview
```

## Structure

```
src/
  components/
    Nav.jsx          top navigation
    Hero.jsx          hero with spotlight cone + particles
    WhoFor.jsx         "who it's for" platform cards
    BrandCollab.jsx    brand stats + scrolling marquee
    Fanbase.jsx        animated connection constellation
    Income.jsx         income streams + stats
    Monetize.jsx       content-type card grid
    HowItWorks.jsx     3-step scroll-drawn timeline
    PassCard.jsx       signature 3D flip card
    PassCTA.jsx        final signup section
    Footer.jsx
    TiltCard.jsx       shared mouse-tilt wrapper
  App.jsx
  main.jsx
  index.css
```

All copy, imagery placeholders, and stats are original/illustrative —
swap the numbers, brand chip names, and form action in `PassCTA.jsx` for
your real ones.

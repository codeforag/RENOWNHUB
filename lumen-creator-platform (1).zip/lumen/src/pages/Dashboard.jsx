import { useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import PageTransition from '../components/PageTransition.jsx'
import { useAuthFlow } from '../context/AuthFlowContext.jsx'

const STATS = [
  { label: 'Earned', value: '₹0' },
  { label: 'Paid', value: '₹0' },
  { label: 'Balance', value: '₹0' },
]

const INSIGHTS = [
  { label: 'Pending orders', value: '0' },
  { label: 'Last post', value: 'No posts yet' },
  { label: 'App visits', value: '0 so far' },
  { label: 'Fans on push notifications', value: '0' },
]

const NAV_ITEMS = ['Home', 'Feed', 'Post', 'Notifications', 'Profile']

function displayName(fullName, signupUsername) {
  if (fullName) return fullName.split(' ')[0]
  if (signupUsername) return signupUsername
  return 'Creator'
}

export default function Dashboard() {
  const navigate = useNavigate()
  const { otpVerified, fullName, signupUsername, categories, socials } = useAuthFlow()

  useEffect(() => {
    if (!otpVerified) navigate('/signin', { replace: true })
  }, [otpVerified, navigate])

  const name = displayName(fullName, signupUsername)
  const linkedSocials = Object.entries(socials || {}).filter(([, v]) => v)

  return (
    <PageTransition>
      <div className="min-h-screen px-6 py-10 max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-10">
          <Link to="/" className="flex items-center gap-2 font-display text-xl tracking-tight">
            <span className="inline-block h-2.5 w-2.5 rounded-full bg-gold shadow-glow animate-pulse-glow" />
            Lumen
          </Link>
          <div className="h-10 w-10 rounded-full bg-gradient-to-br from-gold to-coral flex items-center justify-center font-display text-bg font-semibold">
            {name[0]?.toUpperCase()}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-10"
        >
          <p className="font-mono text-xs tracking-[0.3em] text-gold uppercase mb-2">
            Welcome back
          </p>
          <h1 className="font-display text-4xl mb-3">Hey, {name}.</h1>
          {categories?.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {categories.map((c) => (
                <span
                  key={c}
                  className="text-xs font-mono uppercase tracking-wide rounded-full border border-white/15 px-3 py-1 text-muted"
                >
                  {c.replace('-', ' ')}
                </span>
              ))}
            </div>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="grid sm:grid-cols-3 gap-5 mb-10"
        >
          {STATS.map((s) => (
            <div
              key={s.label}
              className="rounded-2xl border border-white/10 bg-bgAlt p-6"
            >
              <div className="font-display text-3xl mb-1">{s.value}</div>
              <div className="text-sm text-muted">{s.label}</div>
            </div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="grid sm:grid-cols-2 gap-5 mb-10"
        >
          <div className="rounded-2xl border border-white/10 bg-bgAlt p-6">
            <div className="text-sm text-muted mb-4">Insights</div>
            <ul className="space-y-3">
              {INSIGHTS.map((i) => (
                <li key={i.label} className="flex items-center justify-between text-sm">
                  <span className="text-muted">{i.label}</span>
                  <span className="font-medium">{i.value}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-2xl border border-white/10 bg-bgAlt p-6">
            <div className="text-sm text-muted mb-4">Linked socials</div>
            {linkedSocials.length === 0 ? (
              <p className="text-sm text-muted/70">
                No social profiles linked yet — add some from your profile settings
                to help fans find you.
              </p>
            ) : (
              <ul className="space-y-3">
                {linkedSocials.map(([key, value]) => (
                  <li key={key} className="flex items-center justify-between text-sm">
                    <span className="text-muted capitalize">{key}</span>
                    <span className="font-medium truncate max-w-[60%]">{value}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </motion.div>

        <nav className="flex items-center justify-around rounded-2xl border border-white/10 bg-bgAlt py-4 sticky bottom-6">
          {NAV_ITEMS.map((item) => (
            <button
              key={item}
              className="text-xs text-muted hover:text-gold transition-colors font-medium"
            >
              {item}
            </button>
          ))}
        </nav>
      </div>
    </PageTransition>
  )
}

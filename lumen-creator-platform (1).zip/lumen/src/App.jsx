import { Routes, Route, useLocation } from 'react-router-dom'
import { AnimatePresence } from 'framer-motion'

import Home from './pages/Home.jsx'
import SignIn from './pages/SignIn.jsx'
import SignUp from './pages/SignUp.jsx'
import VerifyOtp from './pages/VerifyOtp.jsx'
import ProfileStep from './pages/onboarding/ProfileStep.jsx'
import CategoryStep from './pages/onboarding/CategoryStep.jsx'
import SocialStep from './pages/onboarding/SocialStep.jsx'
import Dashboard from './pages/Dashboard.jsx'

export default function App() {
  const location = useLocation()

  return (
    <div className="bg-bg text-cream font-body min-h-screen" style={{ perspective: 1400 }}>
      <div className="grain" />
      <AnimatePresence mode="wait" initial={false}>
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<Home />} />
          <Route path="/signin" element={<SignIn />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/verify-otp" element={<VerifyOtp />} />
          <Route path="/onboarding/profile" element={<ProfileStep />} />
          <Route path="/onboarding/category" element={<CategoryStep />} />
          <Route path="/onboarding/social" element={<SocialStep />} />
          <Route path="/dashboard" element={<Dashboard />} />
        </Routes>
      </AnimatePresence>
    </div>
  )
}
